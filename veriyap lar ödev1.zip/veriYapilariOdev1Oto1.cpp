//veri yapilari odev1 oto1
//Berfin Zümra Karacakaya
#include <iostream>
#include <string>
#include <Windows.h> // Sleep fonksiyonu için
#include <cstdlib>   // exit fonksiyonu için

using namespace std;
struct Ameliyat {
    string baslangicTarihi;
    string bitisTarihi;
    int odaNumarasi;
    int ucret;
    Ameliyat* next;
    Ameliyat* prev;
    int id;

    Ameliyat(string _baslangicTarihi, string _bitisTarihi, int _odaNumarasi) {
        baslangicTarihi = _baslangicTarihi;
        bitisTarihi = _bitisTarihi;
        odaNumarasi = _odaNumarasi;
        next = nullptr;
        prev = nullptr;
    }
};
// Hasta veri yapısı
struct Hasta {
    string ad;
    string soyad;
    int yas;
    int id;
    int ameliyatOdaNumarasi; // Ameliyat odası numarası
    string ameliyatBaslangicTarihi; // Ameliyat başlangıç tarihi
    string ameliyatBitisTarihi; // Ameliyat bitiş tarihi
    string teshis;
    char sigorta;
    int ucret;
    Ameliyat* ameliyatBas;
    int hastalikderecesi;

    Hasta* next;
    Hasta* prev;
    Ameliyat* ameliyatListesi;
    
    Hasta() : id(0), ad(""), soyad(""), yas(0), ameliyatListesi(nullptr), next(nullptr), prev(nullptr) {}

    Hasta(int _id, string _ad, string _soyad, int _yas) : id(_id), ad(_ad), soyad(_soyad), yas(_yas), ameliyatListesi(nullptr), next(nullptr), prev(nullptr) {}

};


// Doktor veri yapısı
struct Doktor {
    string ad;
    string soyad;
    string kullaniciadi;
    int sifre;
    string email;
    Doktor* prev;
    Doktor* next;
    Hasta* hastaBas; // Her bir doktora ait hasta listesi
};


// Bashekim e-posta gönderme fonksiyonu
void sendEmail(const string& to) {
    // Gerçek bir e-posta gönderme işlemi yapılması gerekmektedir
    cout << "Bashekime E-posta gonderildi: " << to << endl;
}

// Çıkış işlevi
void cikisYap() {
    exit(0); // Programdan çıkış
}
// Renklerin tanımları
enum Renk { KIRMIZI, SARI, YESIL };

// Renk seçeneklerini gösteren fonksiyon
void renkSecenekleriniGoster() {
    cout << "Hastalik derecesine göre renk seçenekleri:" << endl;
    cout << "1. Kirmizi (Agir Hastalik)" << endl;
    cout << "2. Sari (Orta Derecede Hastalik)" << endl;
    cout << "3. Yesil (Hafif Hastalik)" << endl;
}

// Renk seçimini alan fonksiyon
Renk renkSec() {
    int secim;
    cout << "Lutfen hastalik derecesine uygun renk secin: ";
    cin >> secim;

    switch (secim) {
    case 1:
        return KIRMIZI;
    case 2:
        return SARI;
    case 3:
        return YESIL;
    default:
        cout << "Geçersiz renk seçimi! Varsayılan olarak Yeşil seçildi." << endl;
        return YESIL;
    }
}

// Renk kodunu döndüren fonksiyon
string renkKodu(Renk renk) {
    switch (renk) {
    case KIRMIZI:
        return "\033[1;31m"; // Kırmızı renk
    case SARI:
        return "\033[1;33m"; // Sarı renk
    case YESIL:
        return "\033[1;32m"; // Yeşil renk
    default:
        return "\033[1;32m"; // Varsayılan olarak Yeşil renk
    }
}

// Konsol renk kodunu sıfırlayan fonksiyon
string renkSifirla() {
    return "\033[0m";
}


void hastaEkle(Doktor* doktor) {
    string ad, soyad, teshis;
    int yas, id, hastalikderecesi;

    cout << "Hasta adi: ";
    cin >> ad;
    cout << "Hasta soyadi: ";
    cin >> soyad;
    cout << "Hasta yasi: ";
    cin >> yas;
    cout << "Hasta ID: ";
    cin >> id;
    cout << "Hastalik derecesi: ";
    cin >> hastalikderecesi;
    cout << "Hastalik teshisi: ";
    cin >> teshis;
    // Renk seçeneklerini göster
    renkSecenekleriniGoster();
    // Renk seçimini al
    Renk renk = renkSec();

    hastalikderecesi = static_cast<int>(renk); // Hasta eklenirken hastalık derecesi atanıyor


    // Yeni hasta oluştur ve bilgileri ata
    Hasta* yeniHasta = new Hasta;
    yeniHasta->ad = ad;
    yeniHasta->soyad = soyad;
    yeniHasta->yas = yas;
    yeniHasta->id = id; // Hasta ID'sini atama eklenmiş
    yeniHasta->hastalikderecesi = hastalikderecesi; // Hastalık derecesini atama eklenmiş
    yeniHasta->teshis = teshis; // Hastalık teşhisini atama eklenmiş
    yeniHasta->prev = NULL;
    yeniHasta->next = NULL;

    // Doktorun hasta listesine ekle
    if (doktor->hastaBas == NULL) {
        doktor->hastaBas = yeniHasta;
    }
    else {
        Hasta* iter = doktor->hastaBas;
        while (iter->next != NULL) {
            iter = iter->next;
        }
        iter->next = yeniHasta;
        yeniHasta->prev = iter;
    }

    cout << "Yeni hasta basariyla eklendi." << endl;
}
// Hasta silme işlevi
void hastaSil(Doktor* doktor) {
    int silinecekID;
    cout << "Silinecek hasta ID'sini girin: ";
    cin >> silinecekID;

    Hasta* temp = doktor->hastaBas;

    // Başta silme işlemi
    if (temp != NULL && temp->id == silinecekID) {
        doktor->hastaBas = temp->next;
        delete temp;
        cout << "Hasta basariyla silindi." << endl;
        return;
    }

    // Orta ve sondaki silme işlemi
    while (temp != NULL && temp->id != silinecekID) {
        temp = temp->next;
    }

    // Hasta bulunamadıysa
    if (temp == NULL) {
        cout << "ID'si " << silinecekID << " olan hasta bulunamadi." << endl;
        return;
    }

    // Silinecek hasta bulundu
    if (temp->next != NULL) {
        temp->next->prev = temp->prev;
    }
    if (temp->prev != NULL) {
        temp->prev->next = temp->next;
    }

    delete temp;
    cout << "Hasta basariyla silindi." << endl;
}
// Hasta detaylarını getirme işlevi
void hastaDetaylariniGetir(Doktor* doktor) {
    // Doktora ait hasta listesini dolaşarak her hasta için bilgileri ekrana yazdır
    Hasta* iter = doktor->hastaBas;
    if (iter == NULL) {
        cout << "Hastalar bulunamadi." << endl;
        return;
    }

    cout << "Doktora ait hastalarin detaylari:" << endl;
    while (iter != NULL) {
        // Renk kodunu al
        string renkKod = renkKodu(static_cast<Renk>(iter->hastalikderecesi));
        cout << "Hasta adi: " <<renkKod<< iter->ad <<renkSifirla() << endl;
        cout << "Hasta soyadi: " << renkKod<<iter->soyad<<renkSifirla ()<< endl;
        cout << "Hasta yasi: " << iter->yas << endl;
        cout << "Hasta ID: " << iter->id << endl;
        cout << "Hastalik derecesi: " << iter->hastalikderecesi << endl;
        cout << "Hastalik teshisi: " << iter->teshis << endl << endl;
        iter = iter->next;
    }
}
// Çift yönlü dairesel bağlı listeyle bütün hastaları yazdırma
void tumHastalariYazdir(Doktor* doktorlar) {
    if (doktorlar == nullptr) {
        cout << "Doktor bulunmamaktadir." << endl;
        return;
    }

    // Bir dairesel çift yönlü bağlı liste oluştur
    Hasta* bas = nullptr;

    // Doktorları dolaşarak hastaları bağlı listeye ekle
    Doktor* doktorIter = doktorlar;
    while (doktorIter != nullptr) {
        Hasta* hastaIter = doktorIter->hastaBas;
        while (hastaIter != nullptr) {
            Hasta* yeniHasta = new Hasta;
            yeniHasta->ad = hastaIter->ad;
            yeniHasta->soyad = hastaIter->soyad;
            yeniHasta->yas = hastaIter->yas;
            yeniHasta->id = hastaIter->id;
            yeniHasta->hastalikderecesi = hastaIter->hastalikderecesi;
            yeniHasta->teshis = hastaIter->teshis;

            if (bas == nullptr) {
                bas = yeniHasta;
                bas->next = bas;
                bas->prev = bas;
            }
            else {
                yeniHasta->prev = bas->prev;
                yeniHasta->next = bas;
                bas->prev->next = yeniHasta;
                bas->prev = yeniHasta;
            }

            hastaIter = hastaIter->next;
        }
        doktorIter = doktorIter->next;
        if (doktorIter == doktorlar) // Döngüden çık
            break;
    }

    // Dairesel çift yönlü bağlı listeyi dolaşarak hastaları yazdır
    if (bas != nullptr) {
        Hasta* iter = bas;
        do {
            string renkKod = renkKodu(static_cast<Renk>(iter->hastalikderecesi));
            cout << "Hasta adi: " << renkKod << iter->ad << renkSifirla() << endl;
            cout << "Hasta soyadi: " << renkKod << iter->soyad << renkSifirla() << endl;
            cout << "Hasta yasi: " << iter->yas << endl;
            cout << "Hasta ID: " << iter->id << endl;
            cout << "Hastalik derecesi: " << iter->hastalikderecesi << endl;
            cout << "Hastalik teshisi: " << iter->teshis << endl << endl;
            iter = iter->next;
        } while (iter != bas);
    }

    // Belleği temizle
    Hasta* iter = bas;
    while (iter != nullptr) {
        Hasta* temp = iter;
        iter = iter->next;
        delete temp;
        if (iter == bas) // Döngüyü sonlandır
            break;
    }
}
// Ameliyat ekleme işlevi
void ameliyatEkle(Doktor* doktor) {
    // Hasta ID'sini al
    int hastaID;
    cout << "Ameliyat yapilacak hastanin ID'sini girin: ";
    cin >> hastaID;

    // Doktorun hasta listesinde hastaID'ye sahip hasta aranır
    Hasta* iter = doktor->hastaBas;
    while (iter != nullptr) {
        if (iter->id == hastaID) {
            // Belirtilen hasta bulundu, ameliyat bilgileri istenir
            string baslangicTarihi, bitisTarihi;
            int odaNumarasi;

            cout << "Ameliyat baslangic tarihini girin: ";
            cin >> baslangicTarihi;
            cout << "Ameliyat bitis tarihini girin: ";
            cin >> bitisTarihi;
            cout << "Ameliyat odasini numarasini girin: ";
            cin >> odaNumarasi;

            // Yeni ameliyat düğümü oluştur
            Ameliyat* yeniAmeliyat = new Ameliyat(baslangicTarihi, bitisTarihi, odaNumarasi);

            // Ameliyatı hastanın ameliyat listesine ekle
            if (iter->ameliyatListesi == nullptr) {
                iter->ameliyatListesi = yeniAmeliyat;
            }
            else {
                Ameliyat* ameliyatIter = iter->ameliyatListesi;
                while (ameliyatIter->next != nullptr) {
                    ameliyatIter = ameliyatIter->next;
                }
                ameliyatIter->next = yeniAmeliyat;
                yeniAmeliyat->prev = ameliyatIter;
            }

            cout << "Ameliyat basariyla eklendi." << endl;
            return;
        }
        iter = iter->next;
    }

    // Hasta bulunamadıysa
    cout << "ID'si " << hastaID << " olan hasta bulunamadi." << endl;
}
// Ameliyat silme işlevi
void ameliyatSil(Doktor* doktor) {
    int hastaID;
    cout << "Ameliyati silinecek hastanin ID'sini girin: ";
    cin >> hastaID;

    Hasta* temp = doktor->hastaBas;

    // Hasta bulunamadıysa
    while (temp != NULL && temp->id != hastaID) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "ID'si " << hastaID << " olan hasta bulunamadi." << endl;
        return;
    }

    // Ameliyat bilgilerini sıfırla
    temp->ameliyatBaslangicTarihi = "";
    temp->ameliyatBitisTarihi = "";
    temp->ameliyatOdaNumarasi = 0;

    cout << "Ameliyat bilgileri basariyla silindi." << endl;
}
// Ameliyat detaylarını getirme işlevi
void ameliyatDetaylariniGetir(Doktor* doktor, int hastaID) {
    // Doktorun hasta listesinde hastaID'ye sahip hasta aranır
    Hasta* iter = doktor->hastaBas;
    while (iter != nullptr) {
        if (iter->id == hastaID) {
            // Belirtilen hasta bulundu, ameliyat bilgileri yazdırılır 
            cout << "Hasta ID: " << iter->id << endl;
            cout << "Hasta Adi: " << iter->ad << endl;
            cout << "Hasta Soyadi: " << iter->soyad << endl;
            cout << "Hasta Yas: " << iter->yas << endl;

            // Hasta ameliyat listesindeki bilgileri ileri yönde yazdır
            cout << "Ameliyat Detaylari:" << endl;
            Ameliyat* ameliyatIter = iter->ameliyatListesi;
            while (ameliyatIter != nullptr) {
                cout << "  Baslangic Tarihi: " << ameliyatIter->baslangicTarihi << endl;
                cout << "  Bitis Tarihi: " << ameliyatIter->bitisTarihi << endl;
                cout << "  Oda Numarasi: " << ameliyatIter->odaNumarasi << endl;
                cout << "-----------------------" << endl;
                ameliyatIter = ameliyatIter->next;
            }

            // Geriye doğru dolaşarak ameliyat bilgilerini yazdır
            cout << "Ameliyat Detaylari (Geriye Dogru):" << endl;
            while (ameliyatIter != nullptr) {
                cout << "  Baslangic Tarihi: " << ameliyatIter->baslangicTarihi << endl;
                cout << "  Bitis Tarihi: " << ameliyatIter->bitisTarihi << endl;
                cout << "  Oda Numarasi: " << ameliyatIter->odaNumarasi << endl;
                cout << "-----------------------" << endl;
                ameliyatIter = ameliyatIter->prev;
            }

            // Ameliyat bilgileri yazdırıldıktan sonra fonksiyonu sonlandır
            return;
        }
        iter = iter->next;
    }

    // Hasta bulunamadıysa
    cout << "ID'si " << hastaID << " olan hasta bulunamadi." << endl;
}
void tumAmeliyatDetaylariniYazdir(Doktor* doktorlar) {
    if (doktorlar == nullptr) {
        cout << "Doktor bulunmamaktadir." << endl;
        return;
    }

    // Çift yönlü dairesel bağlı liste oluştur
    Ameliyat* bas = nullptr;

    // Doktorları dolaşarak ameliyat detaylarını bağlı listeye ekle
    Doktor* doktorIter = doktorlar;
    do {
        Hasta* hastaIter = doktorIter->hastaBas;
        while (hastaIter != nullptr) {
            Ameliyat* ameliyatIter = hastaIter->ameliyatListesi;
            while (ameliyatIter != nullptr) {
                // Yeni ameliyat düğümü oluştur
                Ameliyat* yeniAmeliyat = new Ameliyat(ameliyatIter->baslangicTarihi, ameliyatIter->bitisTarihi, ameliyatIter->odaNumarasi);
                yeniAmeliyat->id = hastaIter->id; // Hasta ID'sini kaydet

                // Bağlı listeye ekle
                if (bas == nullptr) {
                    bas = yeniAmeliyat;
                    bas->next = bas;
                    bas->prev = bas;
                }
                else {
                    yeniAmeliyat->prev = bas->prev;
                    yeniAmeliyat->next = bas;
                    bas->prev->next = yeniAmeliyat;
                    bas->prev = yeniAmeliyat;
                }

                ameliyatIter = ameliyatIter->next;
            }
            hastaIter = hastaIter->next;
        }
        doktorIter = doktorIter->next;
    } while (doktorIter != doktorlar && doktorIter != nullptr);

    // Bağlı listeyi dolaşarak ameliyat detaylarını ve hasta ID'sini yazdır
    if (bas != nullptr) {
        Ameliyat* iter = bas;
        do {
            cout << "Hasta ID: " << iter->id << endl;
            cout << "Ameliyat Baslangic Tarihi: " << iter->baslangicTarihi << endl;
            cout << "Ameliyat Bitis Tarihi: " << iter->bitisTarihi << endl;
            cout << "Ameliyat Oda Numarasi: " << iter->odaNumarasi << endl;
            cout << "-----------------------" << endl;
            iter = iter->next;
        } while (iter != bas);
    }

    // Belleği temizle
    Ameliyat* iter = bas;
    while (iter != nullptr) {
        Ameliyat* temp = iter;
        iter = iter->next;
        delete temp;
        if (iter == bas) // Döngüyü sonlandır
            break;
    }
}
void ameliyatUcretiHesapla(Doktor* doktor) {
    int hastaID;
    cout << "Ameliyat ucretini hesaplamak istediginiz hastanin ID'sini girin: ";
    cin >> hastaID;

    Hasta* temp = doktor->hastaBas;

    // Hasta bulunamadıysa
    while (temp != NULL && temp->id != hastaID) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "ID'si " << hastaID << " olan hasta bulunamadi." << endl;
        return;
    }

    // Sigorta durumu sorgulanıyor
    char sigorta;
    cout << "Hastanin sigorta durumu (S: SGK, D: Diğer): ";
    cin >> sigorta;

    // Ücret hesaplanıyor
    if (sigorta == 'S' || sigorta == 's') {
        temp->ucret = 100 * temp->hastalikderecesi;
    }
    else if (sigorta == 'D' || sigorta == 'd') {
        temp->ucret = 200 * temp->hastalikderecesi;
    }
    else {
        cout << "Geçersiz sigorta durumu!" << endl;
        return;
    }

    cout << "Ameliyat ucreti: " << temp->ucret << " TL" << endl;
}
// Doktor menüsü işlevi
void doktorMenu(Doktor& doktor) {
    int secim;
    do {
        cout << "\n--- Doktor Menusu ---" << endl;
        cout << "1. Hasta Ekle" << endl;
        cout << "2. ID bilgisi kullanarak hasta sil" << endl;
        cout << "3. Hasta detaylari getir" << endl;
        cout << "4. Ameliyat ekle" << endl;
        cout << "5. Ameliyat sil" << endl;
        cout << "6. Ameliyat detaylarini getir" << endl;
        cout << "7. ID’ye göre ameliyat ucretini hesapla" << endl;
        cout << "8. Ana menuye don" << endl;
        cout << "9. Cıkıs" << endl;
        cout << "Seciminizi yapiniz: ";
        cin >> secim;

        switch (secim) {
        case 1:
            hastaEkle(&doktor);
            break;
        case 2:
            hastaSil(&doktor);
            break;
        case 3:
            hastaDetaylariniGetir(&doktor);
            break;
        case 4:
            ameliyatEkle(&doktor);
            break;

        case 5:
            ameliyatSil(&doktor);
            break;
        case 6:
            int hastaID;
            cout << "Ameliyat detaylarini gormek istediginiz hastanin ID'sini girin: ";
            cin >> hastaID;

            ameliyatDetaylariniGetir(&doktor, hastaID);
            break;
        case 7:
            ameliyatUcretiHesapla(&doktor);
            break;

        case 8:
            cout << "Ana menüye dönülüyor..." << endl;
            return;
        case 9:
            cout << "Cikis yapiliyor..." << endl;
            cikisYap();
            break;
        default:
            cout << "Gecersiz secim!" << endl;
            break;
        }
    } while (secim != 9);
}
void doktorGirisi(Doktor* basdugum, int doktorSayisi) {
    int dogruHak = 3;

    while (dogruHak > 0) {
        string kullaniciAdi;
        int sifre;
        cout << "Kullanici adi: ";
        cin >> kullaniciAdi;
        cout << "Sifre: ";
        cin >> sifre;

        // Kullanıcı adı ve şifre doğruysa
        bool dogruGiris = false;
        Doktor* temp = basdugum;
        while (temp != NULL) {
            if (kullaniciAdi == temp->kullaniciadi && sifre == temp->sifre) {
                dogruGiris = true;
                doktorMenu(*temp);
                // Doktor menüsüne yönlendir
                // doktorMenu() fonksiyonu çağrılacak
                return; // Çıkış işlevini çağırmadan önce fonksiyondan çık
            }
            temp = temp->next;
        }

        if (!dogruGiris) {
            dogruHak--;
            if (dogruHak > 1) {
                cout << "Yanlis kullanici adi veya sifre. Kalan hakkiniz: " << dogruHak << endl;
            }
            else if (dogruHak == 1) {
                cout << "2 defa yanlis giris tespit edildi. 5 dakika sonra tekrar deneyin." << endl;
                Sleep(5000); // 5 dakika beklet
            }
        }
    }

    cout << "3.defa yanlis giris yaptiniz.Sistemden cikiliyor.Bas hekime mail gönderilcek." << endl;
    // Eğer buraya kadar geldiyse, tüm haklar tükenmiş demektir
    sendEmail("zumrakrcky@gmail.com");
    cikisYap();
}
struct Doktor* basaEkle(Doktor* basdugum, string isim, string soyisim, string k_adi, int parola) {
    if (basdugum == NULL) {
        struct Doktor* dugum = new Doktor();
        dugum->ad = isim;
        dugum->soyad = soyisim;
        dugum->kullaniciadi = k_adi;
        dugum->sifre = parola;
        dugum->next = NULL;
        basdugum = dugum;
    }
    else {
        struct Doktor* dugum = new Doktor();
        dugum->next = basdugum;
        dugum->ad = isim;
        dugum->soyad = soyisim;
        dugum->kullaniciadi = k_adi;
        dugum->sifre = parola;
        basdugum = dugum;
    }
    return basdugum;
}
struct Doktor* sonaEkle(Doktor* basdugum, string isim, string soyisim, string k_adi, int parola) {
    if (basdugum == NULL) {
        struct Doktor* dugum = new Doktor();
        dugum->ad = isim;
        dugum->soyad = soyisim;
        dugum->kullaniciadi = k_adi;
        dugum->sifre = parola;
        dugum->next = NULL;
        basdugum = dugum;
    }
    else {
        struct Doktor* dugum = new Doktor();
        struct Doktor* temp = basdugum;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = dugum;
        dugum->ad = isim;
        dugum->soyad = soyisim;
        dugum->kullaniciadi = k_adi;
        dugum->sifre = parola;
        dugum->next = NULL;

    } return basdugum;
}
struct Doktor* ekle(Doktor* basdugum, string isim, string soyisim, string k_adi, int parola) {
    if (basdugum == NULL) {
        struct Doktor* dugum = new Doktor();
        dugum->ad = isim;
        dugum->soyad = soyisim;
        dugum->kullaniciadi = k_adi;
        dugum->sifre = parola;
        dugum->next = NULL;
        basdugum = dugum;
    }
    else {
        struct Doktor* dugum = new Doktor();
        struct Doktor* temp = basdugum;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = dugum;
        dugum->ad = isim;
        dugum->soyad = soyisim;
        dugum->kullaniciadi = k_adi;
        dugum->sifre = parola;
        dugum->next = NULL;
    }
    return basdugum;

}
struct Doktor* arayaEkle(Doktor* basdugum, string isim, string soyisim, string k_adi, int sifre, int aranandeger) {
    if (basdugum == NULL) {
        cout << "Liste bos";
    }
    else if (basdugum->next == NULL) {
        if (basdugum->sifre == aranandeger) {
            struct Doktor* dugum = new Doktor();
            dugum->next = basdugum;
            dugum->ad = isim;
            dugum->soyad = soyisim;
            dugum->kullaniciadi = k_adi;
            dugum->sifre = sifre;
            basdugum = dugum;
        }
    }
    else {
        struct Doktor* dugum = new Doktor();
        struct Doktor* temp = basdugum;
        while (temp->next->sifre != aranandeger) {
            temp = temp->next;
        }
        struct Doktor* temp2 = temp->next;
        temp->next = dugum;
        dugum->ad = isim;
        dugum->soyad = soyisim;
        dugum->kullaniciadi = k_adi;
        dugum->sifre = sifre;
        dugum->next = temp2;
    }
    return basdugum;
}
void doktorlariYazdir(Doktor* basdugum) {

    if (basdugum == NULL) {
        cout << "Liste bos" << endl;
        return;
    }

    Doktor* temp = basdugum;
    do {
        cout << "Doktor Adi: " << temp->ad << endl; // Doğru: temp->ad yerine temp->kullaniciadi veya doktor adını temsil eden bir üye değişkeni
        cout << "Doktor Soyadi: " << temp->soyad << endl; // Doğru: temp->soyad yerine temp->sifre veya doktor soyadını temsil eden bir üye değişkeni
        temp = temp->next;
    } while (temp != basdugum);
}
void hastalikOncelikPuanlariniHesapla(Doktor* basdugum) {
    if (basdugum == nullptr) {
        cout << "Doktor bulunamadi." << endl;
        return;
    }

    Doktor* tempDoktor = basdugum;
    do {
       

        Hasta* tempHasta = tempDoktor->hastaBas;
        if (tempHasta == nullptr) {
            cout << "Doktora ait hastalar bulunamadi." << endl;
        }
        else {
            cout << "Doktora ait hastalarin oncelik puanlari:" << endl;
            Hasta* ilkHasta = tempHasta;
            do {
                // Hasta öncelik puanını hesapla
                int oncelikPuan = tempHasta->hastalikderecesi * 15;
                cout << "Hasta Adı: " << tempHasta->ad << endl;
                cout << "Hasta Soyadı: " << tempHasta->soyad << endl;
                cout << "Hasta Yası: " << tempHasta->yas << endl;
                cout << "Hastalık Derecesi: " << tempHasta->hastalikderecesi << endl;
                cout << "Hastalık Teshisi: " << tempHasta->teshis << endl;
                cout << "Hasta Oncelik Puani: " << oncelikPuan << endl << endl;

                tempHasta = tempHasta->next;
            } while (tempHasta != nullptr && tempHasta != ilkHasta); // Sonraki düğüm null olmadığı ve döngü başlangıç düğümüne geri dönmediği sürece devam et
        }

        tempDoktor = tempDoktor->next;
    } while (tempDoktor != basdugum && tempDoktor != nullptr); // tempDoktor NULL değil olduğu sürece devam et
}
void verileriDaireselListeyeAktar(Doktor* basdugum) {
    if (basdugum == NULL) {
        cout << "Aktarilacak veri yok." << endl;
        return;
    }

    Doktor* sonEleman = basdugum;
    while (sonEleman->next != NULL) {
        sonEleman = sonEleman->next;
    }

    // Son elemanın next'i baş elemanı göstersin
    sonEleman->next = basdugum;

    // Baş elemanın prev'i son elemanı göstersin
    basdugum->prev = sonEleman;
}
// Hasta menüsü işlevi
void hastaMenu(Doktor* doktorlar) {
    verileriDaireselListeyeAktar(doktorlar);
    int secim;
    do {
        cout << "\n--- Hasta Menusu ---" << endl;
        cout << "1. Hastane doktorlarini yazdir" << endl;
        cout << "2. Tum hastalari yazdir" << endl;
        cout << "3. Ameliyat hastalarini yazdir" << endl;
        cout << "4. Tum hastalarin oncelik puanlarini yazdir" << endl;
        cout << "5. Ana menuye don" << endl;
        cout << "6. Cikis" << endl;
        cout << "Seciminizi yapiniz: ";
        cin >> secim;

        switch (secim) {
        case 1:
            cout << "Hastane doktorlari:" << endl;
            doktorlariYazdir(doktorlar);
            break;
        case 2:
            cout << "Tum hastalar:" << endl;
            // Tüm hastaları yazdırma işlevi çağrılacak
            tumHastalariYazdir(doktorlar);
            break;
        case 3:
            cout << "Ameliyat hastalari:" << endl;
            // Ameliyat hastalarını yazdırma işlevi çağrılacak
            tumAmeliyatDetaylariniYazdir(doktorlar);
            break;
        case 4:
            cout << "Tum hastalarin oncelik puanlari:" << endl;
            hastalikOncelikPuanlariniHesapla(doktorlar);
            break;
        case 5:
            cout << "Ana menüye dönülüyor..." << endl;
            return;
        case 6:
            cout << "Cikis yapiliyor..." << endl;
            cikisYap();
            break;
        default:
            cout << "Gecersiz secim!" << endl;
            break;
        }
    } while (secim != 6);
}
int hastaSayisi(Hasta* bas) {
    if (bas == nullptr) // Liste boşsa 0 döndür
        return 0;

    int count = 0;
    Hasta* iter = bas; 

    do {
        count++; 
        iter = iter->next; 
    } while (iter != nullptr && iter != bas); 
    return count; 
}
int tumHastaSayisi(Doktor* doktorlar) {
    if (doktorlar == nullptr) 
        return 0;

    int toplamHastaSayisi = 0; 
    
    Doktor* doktorIter = doktorlar;
    do {
        toplamHastaSayisi += hastaSayisi(doktorIter->hastaBas); 
        doktorIter = doktorIter->next; 
    } while (doktorIter != nullptr && doktorIter != doktorlar); 

    return toplamHastaSayisi; 
}
void toplamAmeliyatSayisi(Doktor* doktorlar) {
    if (doktorlar == nullptr) {
        cout << "Doktor bulunmamaktadir." << endl;
        return;
    }

    // Her bir doktor için toplam ameliyat sayısını hesapla ve yazdır
    Doktor* doktorIter = doktorlar;
    do {
        int toplamAmeliyat = 0; // Her bir doktor için toplam ameliyat sayısını tutacak değişken
        Hasta* hastaIter = doktorIter->hastaBas;
        while (hastaIter != nullptr) {
            // Hasta ameliyat listesini dolaşarak toplam ameliyat sayısını hesapla
            Ameliyat* ameliyatIter = hastaIter->ameliyatListesi;
            while (ameliyatIter != nullptr) {
                toplamAmeliyat++;
                ameliyatIter = ameliyatIter->next;
            }
            hastaIter = hastaIter->next;
        }
        // Doktorun adı ve toplam ameliyat sayısını yazdır
        cout << "Doktor " << doktorIter->ad << " icin toplam ameliyat sayisi: " << toplamAmeliyat << endl;

        doktorIter = doktorIter->next;
    } while (doktorIter != doktorlar && doktorIter != nullptr);
}
int renkSayisiniBul(Doktor* doktorlar) {
    if (doktorlar == nullptr) {
        cout << "Doktor bulunamadi." << endl;
        return 0;
    }

    int kirmiziSayisi = 0, sariSayisi = 0, yesilSayisi = 0;

    Doktor* ilkDoktor = doktorlar;
    Doktor* tempDoktor = doktorlar;

    do {
        if (tempDoktor == nullptr) {
            cout << "Hata: Geçersiz doktor." << endl;
            return 0;
        }

        Hasta* ilkHasta = tempDoktor->hastaBas;
        if (ilkHasta != nullptr) {
            Hasta* tempHasta = ilkHasta;
            do {
                switch (tempHasta->hastalikderecesi) {
                case KIRMIZI:
                    kirmiziSayisi++;
                    break;
                case SARI:
                    sariSayisi++;
                    break;
                case YESIL:
                    yesilSayisi++;
                    break;
                }
                tempHasta = tempHasta->next;
            } while (tempHasta != nullptr && tempHasta != ilkHasta); // Dairesel liste kontrolü
        }
        tempDoktor = tempDoktor->next;
    } while (tempDoktor != nullptr && tempDoktor != ilkDoktor); // Dairesel liste kontrolü

    cout << "Toplam Kirmizi Hastalar: " << kirmiziSayisi << endl;
    cout << "Toplam Sari Hastalar: " << sariSayisi << endl;
    cout << "Toplam Yesil Hastalar: " << yesilSayisi << endl;

    // Toplam renk sayısını döndür
    return kirmiziSayisi + sariSayisi + yesilSayisi;
}
void hastaneDegerlendir(Doktor* doktorlar) {
    // Çift yönlü dairesel bağlı listedeki toplam hasta sayısını bul
    int toplamHasta = tumHastaSayisi(doktorlar);
    cout << "Tum doktorlara ait toplam hasta sayisi: " << toplamHasta << endl;

    toplamAmeliyatSayisi(doktorlar);
    renkSayisiniBul(doktorlar);

    
}

int main() {
    // Doktor verileri
    const int doktorSayisi = 4;
    Doktor* doktorlar = NULL;
    doktorlar = basaEkle(doktorlar, "Zumra", "Karacakaya", "zumrakrcky", 111);
    doktorlar = sonaEkle(doktorlar, "Zeynep", "Karatas", "zeynepkaratas", 222);
    doktorlar = sonaEkle(doktorlar, "Sena", "Ozyoruk", "senaozyoruk", 444);
    doktorlar = arayaEkle(doktorlar, "Fatma", "Allaham", "fatmallaham", 333, 222);


    int secim;
    while (true) {
        // Kullanıcıya seçenekleri sunalım
        cout << "Lutfen giris yapmak istediginiz kullanici turunu secin:" << endl;
        cout << "1. Doktor" << endl;
        cout << "2. Hasta" << endl;
        cout << "3. Hastane degerlendir" << endl;
        cout << "4. Cikis" << endl;
        cout << "Seciminizi yapin (1, 2 veya 3): ";
        cin >> secim;

        // Kullanıcının seçimine göre işlem yapalım
        switch (secim) {
        case 1:
            doktorGirisi(doktorlar, doktorSayisi);
            break;
        case 2:
            hastaMenu(doktorlar);
            break;
        case 3:
            hastaneDegerlendir(doktorlar);
            break;
        case 4:
            cout << "Cikis yapiliyor..." << endl;
            return 0;
        default:
            cout << "Gecersiz secim!" << endl;
            break;
        }
    }
}
