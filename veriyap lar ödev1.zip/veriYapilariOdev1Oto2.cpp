//veri yapilari odev1 oto2
//Berfin Zümra Karacakaya
//b231200038
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

// Ürünü temsil eden yapı
struct Urun {
    int id;
    string ad;
    float fiyat;
    Urun* sonraki;
};

// Ürün takip sistemi sınıfı
class UrunTakipSistemi {
private:
    Urun* bas; // Bağlı listenin başı

public:
    // Kurucu fonksiyon
    UrunTakipSistemi() {
        bas = nullptr;
    }

    // Ürünü listeye ekleme
    void urunEkle(int id, string ad, float fiyat) {
        Urun* yeniUrun = new Urun;
        yeniUrun->id = id;
        yeniUrun->ad = ad;
        yeniUrun->fiyat = fiyat;
        yeniUrun->sonraki = nullptr;

        if (bas == nullptr) {
            bas = yeniUrun;
        }
        else {
            Urun* temp = bas;
            while (temp->sonraki != nullptr) {
                temp = temp->sonraki;
            }
            temp->sonraki = yeniUrun;
        }
        cout << "Urun basariyla eklendi." << endl;
    }

    // Ürünü listeden silme
    void urunSil(int id) {
        if (bas == nullptr) {
            cout << "Liste bos, silinecek urun bulunamadi." << endl;
            return;
        }

        if (bas->id == id) {
            Urun* temp = bas;
            bas = bas->sonraki;
            delete temp;
            cout << "Urun basariyla silindi." << endl;
            return;
        }

        Urun* onceki = bas;
        Urun* simdiki = bas->sonraki;
        while (simdiki != nullptr) {
            if (simdiki->id == id) {
                onceki->sonraki = simdiki->sonraki;
                delete simdiki;
                cout << "Urun basariyla silindi." << endl;
                return;
            }
            onceki = simdiki;
            simdiki = simdiki->sonraki;
        }

        cout << "Urun bulunamadi." << endl;
    }

    // Ürünü arama
    bool urunAra(int id) {
        if (bas == nullptr) {
            cout << "Liste bos, aranacak urun bulunamadi." << endl;
            return false;
        }

        Urun* temp = bas;
        bool bulundu = false;
        while (temp != nullptr) {
            if (temp->id == id) {
                cout << "Urun bulundu." << endl;
                bulundu = true;
                break;
            }
            temp = temp->sonraki;
        }

        if (!bulundu) {
            cout << "Urun bulunamadi. Alternatif urunler:" << endl;
            // Alternatif ürünleri listeleme
            temp = bas;
            while (temp != nullptr) {
                cout << "ID: " << temp->id << ", Ad: " << temp->ad << ", Fiyat: " << temp->fiyat << endl;
                temp = temp->sonraki;
            }

            // Urun ID'sini dosyaya yazma
            ofstream bildirimDosyasi("urun_bulunamadi_bildirimi.txt", ios::app);
            if (bildirimDosyasi.is_open()) {
                bildirimDosyasi << "Urun bulunamadi. ID: " << id << endl;
                bildirimDosyasi.close();
                cout << "Mudure bildirim dosyaya yazildi." << endl;
            }
            else {
                cout << "Mudure bildirim dosyasi acilamadi." << endl;
            }
        }

        return bulundu;
    }

    void urunYazdir(int id) {
        bool urunVar = urunAra(id);
        if (urunVar) {
            // Ürün bulundu, bilgilerini yazdır
            Urun* urun = bas; // Başlangıç noktasını al
            while (urun != nullptr) {
                if (urun->id == id) {
                    cout << "Urun bilgileri:" << endl;
                    cout << "ID: " << urun->id << endl;
                    cout << "Ad: " << urun->ad << endl;
                    cout << "Fiyat: " << urun->fiyat << endl;
                    return;
                }
                urun = urun->sonraki;
            }
        }
        else {
            cout << "Urun bulunamadi." << endl;
        }
    }


    // Tüm ürünleri yazdır
    void tumUrunleriYazdir() {
        if (bas == nullptr) {
            cout << "Liste bos, yazdirilacak urun bulunamadi." << endl;
            return;
        }

        cout << "Tum urunler:" << endl;
        Urun* temp = bas;
        while (temp != nullptr) {
            cout << "ID: " << temp->id << ", Ad: " << temp->ad << ", Fiyat: " << temp->fiyat << endl;
            temp = temp->sonraki;
        }
    }

    // Fiyata göre sıralama ve ürünleri yazdırma
    void fiyataGoreSiralamaVeYazdir() {
        // Bağlı listede hiç ürün yoksa mesaj yazdır ve fonksiyondan çık
        if (bas == nullptr) {
            cout << "Liste bos, siralanacak urun bulunamadi." << endl;
            return;
        }

        // Bağlı listedeki ürünleri fiyata göre sıralama
        sirala();

        // Sıralı ürünleri ekrana yazdırma
        cout << "Kucukten buyuge siralanan urunler:" << endl;
        Urun* temp = bas;
        while (temp != nullptr) {
            cout << "Ad: " << temp->ad << ", Fiyat: " << temp->fiyat << endl;
            temp = temp->sonraki;
        }
    }
    float toplamFiyatiHesapla() {
        float toplamFiyat = 0.0;
        Urun* temp = bas;
        while (temp != nullptr) {
            toplamFiyat += temp->fiyat;
            temp = temp->sonraki;
        }
        return toplamFiyat;
    }
    void tumUrunlereZamYap() {
        Urun* temp = bas;
        while (temp != nullptr) {
            // Her ürünün fiyatına %10 zam yap
            temp->fiyat *= 1.1; // Fiyata %10 zam yapmak için 1.1 ile çarpmalıyız
            temp = temp->sonraki;
        }
        cout << "Tum urunlere %10 zam yapildi." << endl;
    }
    // Minimum maliyetli ürünü getiren fonksiyon
    Urun minimumMaliyetliUrun() {
        if (bas == nullptr) {
            cout << "Liste bos, minimum maliyetli urun bulunamadi." << endl;
            return Urun{ -1, "", -1.0, nullptr }; // Hatalı bir ürün döndür
        }

        Urun* temp = bas;
        Urun minimumUrun = *temp; // İlk ürünü minimum olarak kabul et

        while (temp != nullptr) {
            if (temp->fiyat < minimumUrun.fiyat) {
                minimumUrun = *temp;
            }
            temp = temp->sonraki;
        }

        cout << "Minimum maliyetli urun: " << endl;
        cout << "ID: " << minimumUrun.id << ", Ad: " << minimumUrun.ad << ", Fiyat: " << minimumUrun.fiyat << endl;

        return minimumUrun;
    }
    // Maksimum maliyetli ürünü getiren fonksiyon
    Urun maksimumMaliyetliUrun() {
        if (bas == nullptr) {
            cout << "Liste bos, maksimum maliyetli urun bulunamadi." << endl;
            return Urun{ -1, "", -1.0, nullptr }; // Hatalı bir ürün döndür
        }

        Urun* temp = bas;
        Urun maksimumUrun = *temp; // İlk ürünü maksimum olarak kabul et

        while (temp != nullptr) {
            if (temp->fiyat > maksimumUrun.fiyat) {
                maksimumUrun = *temp;
            }
            temp = temp->sonraki;
        }

        cout << "Maksimum maliyetli urun: " << endl;
        cout << "ID: " << maksimumUrun.id << ", Ad: " << maksimumUrun.ad << ", Fiyat: " << maksimumUrun.fiyat << endl;

        return maksimumUrun;
    }
    // Verilen fiyata sahip diğer ürünlerin toplam sayısını bulan fonksiyon
    int ayniMaliyetliUrunSayisi(float fiyat) {
        int sayac = 0;

        if (bas == nullptr) {
            cout << "Liste bos, ayni maliyetli urun bulunamadi." << endl;
            return sayac;
        }

        Urun* temp = bas;
        while (temp != nullptr) {
            if (temp->fiyat == fiyat) {
                sayac++;
            }
            temp = temp->sonraki;
        }

        cout << "Toplam ayni maliyetli urun sayisi: " << sayac << endl;

        return sayac;
    }
private:
    // Bağlı listedeki ürünleri fiyata göre sırala
    void sirala() {
        Urun* current = bas, * index = nullptr;
        float tempFiyat;
        string tempAd;

        if (bas == nullptr) {
            return;
        }
        else {
            while (current != nullptr) {
                // Index her seferinde sıfırlanır
                index = current->sonraki;

                while (index != nullptr) {
                    // Fiyata göre sıralama
                    if (current->fiyat > index->fiyat) {
                        tempFiyat = current->fiyat;
                        current->fiyat = index->fiyat;
                        index->fiyat = tempFiyat;

                        // İsimleri değiştirme
                        tempAd = current->ad;
                        current->ad = index->ad;
                        index->ad = tempAd;
                    }
                    index = index->sonraki;
                }
                current = current->sonraki;
            }
        }
    }
 


    // Yıkıcı fonksiyon
public:
    ~UrunTakipSistemi() {
        while (bas != nullptr) {
            Urun* temp = bas;
            bas = bas->sonraki;
            delete temp;
        }
    }
    public:
        // Minimum maliyetli ürünü getiren fonksiyon
        void minimumMaliyetliUrunuYazdir() {
            minimumMaliyetliUrun(); // minimumMaliyetliUrun fonksiyonunu çağırır
        }
        // Maksimum maliyetli ürünü getiren fonksiyon
        void maksimumMaliyetliUrunuYazdir() {
            maksimumMaliyetliUrun(); // maksimumMaliyetliUrun fonksiyonunu çağırır
        }
        // Verilen fiyata sahip diğer ürünlerin toplam sayısını bulan fonksiyon
        void ayniMaliyetliUrunSayisiniYazdir(float fiyat) {
            ayniMaliyetliUrunSayisi(fiyat); // ayniMaliyetliUrunSayisi fonksiyonunu çağırır
        }
        // Tüm ürünleri dosyaya yazdıran fonksiyon
        void tumUrunleriDosyayaYaz(const string& dosyaAdi) {
            ofstream dosya(dosyaAdi);

            if (!dosya.is_open()) {
                cout << "Dosya acilamadi." << endl;
                return;
            }

            if (bas == nullptr) {
                dosya << "Liste bos, yazdirilacak urun bulunamadi." << endl;
                dosya.close();
                return;
            }

            Urun* temp = bas;
            while (temp != nullptr) {
                dosya << "ID: " << temp->id << ", Ad: " << temp->ad << ", Fiyat: " << temp->fiyat << endl;
                temp = temp->sonraki;
            }

            cout << "Tum urunler dosyaya yazdirildi." << endl;
            dosya.close();
        }
        // Dosyadan ürünleri okuyan fonksiyon
        void dosyadanUrunleriOku(const string& dosyaAdi) {
            ifstream dosya("urunler.txt");

            if (!dosya.is_open()) {
                cout << "Dosya acilamadi." << endl;
                return;
            }

            string satir;
            while (getline(dosya, satir)) {
                cout << satir << endl; // Eğer okunan verileri ekrana yazdırmak istiyorsanız burayı değiştirin.
                // Eğer okunan verileri başka bir yere saklamak istiyorsanız, burada uygun bir veri yapısı kullanarak işlem yapabilirsiniz.
            }

            dosya.close();
        }


        void urunGuncelle(int id) {
            Urun* temp = bas;
            bool bulundu = false;

            // Ürünü bul
            while (temp != nullptr) {
                if (temp->id == id) {
                    bulundu = true;
                    break;
                }
                temp = temp->sonraki;
            }

            if (!bulundu) {
                cout << "Guncellenecek urun bulunamadi." << endl;
                cout << "Mudure bildirildi." << endl;

                // Mevcut ürünleri göster
                cout << "Alternatif urunler:" << endl;
                temp = bas;
                while (temp != nullptr) {
                    cout << "ID: " << temp->id << ", Ad: " << temp->ad << ", Fiyat: " << temp->fiyat << endl;
                    temp = temp->sonraki;
                }

                // Dosyaya yaz
                ofstream dosya("bulunamayan_urunler.txt", ios::app);
                if (dosya.is_open()) {
                    dosya << "Guncellenmek istenen urun ID'si: " << id << endl;
                    dosya.close();
                }
                else {
                    cout << "Dosya acilamadi!" << endl;
                }

                return;
            }

            // Yeni bilgileri al
            string yeniAd;
            float yeniFiyat;
            cout << "Yeni ad girin: ";
            cin.ignore();
            getline(cin, yeniAd);
            cout << "Yeni fiyat girin: ";
            cin >> yeniFiyat;

            // Ürünü güncelle
            temp->ad = yeniAd;
            temp->fiyat = yeniFiyat;

            cout << "Urun basariyla guncellendi." << endl;
        }

};


int main() {
    UrunTakipSistemi sistem;

    int secim;
    do {
        cout << "Urun takip otomasyonuna Hos Geldiniz" << endl;
        cout << "Yapmak istediginiz islemi secin:" << endl;
        cout << "1. Urun ekle" << endl;
        cout << "2. Urun sil" << endl;
        cout << "3. Urunleri ID'ye göre guncelle" << endl;
        cout << "4. Listede urun ara" << endl;
        cout << "5.Aranan urunu yazdir" << endl;
        cout << "6. Tum urunleri yazdir" << endl;
        cout << "7. Fiyata gore sirali urunleri yazdir" << endl;
        cout << "8. Listede yer alan tum urunlerin toplam maliyetini hesapla" << endl;
        cout << "9. Tum urunlere %10 zam yap" << endl;
        cout << "10. Minimum maliyetli urunu yazdir" << endl;
        cout << "11. Maksimum maliyetli urunu yazdir" << endl;
        cout << "12. Ayni maliyette olan urunleri bul" << endl;
        cout << "13. Tum urunleri dosyaya yazdir" << endl;
        cout << "14. Dosyadan urunleri oku" << endl;
        cout << "15. Cikis" << endl;
        cout << "Seciminiz: ";
        cin >> secim;

        switch (secim) {
        case 1: {
            int id;
            string ad;
            float fiyat;
            cout << "Urunun ID'sini girin: ";
            cin >> id;
            cout << "Urunun adini girin: ";
            cin.ignore();
            getline(cin, ad);
            cout << "Urunun fiyatini girin: ";
            cin >> fiyat;
            sistem.urunEkle(id, ad, fiyat);
            break;
        }
        case 2: {
            int id;
            cout << "Silinecek urunun ID'sini girin: ";
            cin >> id;
            sistem.urunSil(id);
            break;
        }
        case 3: {
            int id;
            cout << "Guncellenecek urunun ID'sini girin: ";
            cin >> id;
            sistem.urunGuncelle(id);
            break;
        }
        case 4: {
            int arananID;
            cout << "Aranacak urunun ID'sini girin: ";
            cin >> arananID;

            // Ürünü ara ve stokta olup olmadığını kontrol et
            bool stokta = sistem.urunAra(arananID);

            if (stokta) {
                cout << "Urun stokta." << endl;
            }
            else {
                cout << "Urun stokta degil." << endl;
            }
            break;
        }
        case 5: {
            int arananID;
            cout << "Aranacak urunun ID'sini girin: ";
            cin >> arananID;

            // Ürünü ekrana yazdır
            sistem.urunYazdir(arananID);
            break;
        }
        case 6: {
            // Tüm ürünleri yazdır
            sistem.tumUrunleriYazdir();
            break;
        }
        case 7: {
            // Ürünleri fiyata göre sırala ve yazdır
            sistem.fiyataGoreSiralamaVeYazdir();
            break;
        }
        case 8: {
            // Tüm ürünlerin toplam fiyatını hesapla ve yazdır
            float toplamFiyat = sistem.toplamFiyatiHesapla();
            cout << "Tum urunlerin toplam fiyati: " << toplamFiyat << endl;
            break;
        }
        case 9: {
            sistem.tumUrunlereZamYap();
            break;
        }
        case 10: {
            sistem.minimumMaliyetliUrun();
            break;
        }
        case 11: {
            sistem.maksimumMaliyetliUrunuYazdir();
            break;
        }
        case 12: {
            float fiyat;
            cout << "Fiyat girin: ";
            cin >> fiyat;
            sistem.ayniMaliyetliUrunSayisiniYazdir(fiyat);
            break;
        }
        case 13: {
            string dosyaAdi;
            cout << "Dosya adi girin: ";
            cin >> dosyaAdi;
            sistem.tumUrunleriDosyayaYaz(dosyaAdi);
            break;
        }
        case 14: {
            sistem.dosyadanUrunleriOku("urunler.txt");


            break;
        }
        case 15: {
            cout << "Programdan cikiliyor..." << endl;
            break;
        }
        default:
            cout << "Gecersiz secim. Tekrar deneyin." << endl;
        }
    } while (secim != 14);

    return 0;
}
